PLAYSTATION MOVE BATTERY LEVELS TOOL
by Raphaël de Courville
https://vimeo.com/sableraf/

Connect any number of controllers and run the program.
Each sphere displays the battery level and charging status of the controller.

Translation:

Flickering red   -> LOW
Orange           -> 20% or more
Yellow           -> 40% or more
Light green      -> 60% or more
Bright green     -> 80% or more
Brightest green  -> MAX
Glowing blue     -> CHARGING
Blue             -> CHARGING DONE


Made in Processing

Distributed under the GRL CreativeCommons license: http://goo.gl/Ypucq 
attribution-noncommercial-repercussions-3-0-unported-cc-by-nc-3-0